var express = require('express');
var request = require('request');
var router = express.Router();

/* GET weather update from weather api. */
router.get('/', function(req, res, next) {
  
  // use request to show weather updates
  


});

module.exports = router;
